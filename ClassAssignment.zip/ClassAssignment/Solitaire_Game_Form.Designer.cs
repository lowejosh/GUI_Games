﻿namespace ClassAssignment {
    partial class Solitaire_Game_Form {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.playAreaTable1 = new System.Windows.Forms.TableLayoutPanel();
            this.playAreaTable2 = new System.Windows.Forms.TableLayoutPanel();
            this.playAreaTable4 = new System.Windows.Forms.TableLayoutPanel();
            this.playAreaTable3 = new System.Windows.Forms.TableLayoutPanel();
            this.playAreaTable7 = new System.Windows.Forms.TableLayoutPanel();
            this.playAreaTable6 = new System.Windows.Forms.TableLayoutPanel();
            this.playAreaTable5 = new System.Windows.Forms.TableLayoutPanel();
            this.drawPilePicture = new System.Windows.Forms.PictureBox();
            this.discardPilePicture = new System.Windows.Forms.PictureBox();
            this.suitPilePicture2 = new System.Windows.Forms.PictureBox();
            this.suitPilePicture1 = new System.Windows.Forms.PictureBox();
            this.suitPilePicture4 = new System.Windows.Forms.PictureBox();
            this.suitPilePicture3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.drawPilePicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.discardPilePicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.suitPilePicture2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.suitPilePicture1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.suitPilePicture4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.suitPilePicture3)).BeginInit();
            this.SuspendLayout();
            // 
            // playAreaTable1
            // 
            this.playAreaTable1.AutoSize = true;
            this.playAreaTable1.ColumnCount = 1;
            this.playAreaTable1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.playAreaTable1.Location = new System.Drawing.Point(92, 192);
            this.playAreaTable1.Name = "playAreaTable1";
            this.playAreaTable1.RowCount = 15;
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable1.Size = new System.Drawing.Size(80, 640);
            this.playAreaTable1.TabIndex = 0;
            // 
            // playAreaTable2
            // 
            this.playAreaTable2.AutoSize = true;
            this.playAreaTable2.ColumnCount = 1;
            this.playAreaTable2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.playAreaTable2.Location = new System.Drawing.Point(190, 192);
            this.playAreaTable2.Name = "playAreaTable2";
            this.playAreaTable2.RowCount = 15;
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable2.Size = new System.Drawing.Size(80, 640);
            this.playAreaTable2.TabIndex = 1;
            // 
            // playAreaTable4
            // 
            this.playAreaTable4.AutoSize = true;
            this.playAreaTable4.ColumnCount = 1;
            this.playAreaTable4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.playAreaTable4.Location = new System.Drawing.Point(386, 192);
            this.playAreaTable4.Name = "playAreaTable4";
            this.playAreaTable4.RowCount = 15;
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable4.Size = new System.Drawing.Size(80, 640);
            this.playAreaTable4.TabIndex = 3;
            // 
            // playAreaTable3
            // 
            this.playAreaTable3.AutoSize = true;
            this.playAreaTable3.ColumnCount = 1;
            this.playAreaTable3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.playAreaTable3.Location = new System.Drawing.Point(288, 192);
            this.playAreaTable3.Name = "playAreaTable3";
            this.playAreaTable3.RowCount = 15;
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable3.Size = new System.Drawing.Size(80, 640);
            this.playAreaTable3.TabIndex = 2;
            // 
            // playAreaTable7
            // 
            this.playAreaTable7.AutoSize = true;
            this.playAreaTable7.ColumnCount = 1;
            this.playAreaTable7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.playAreaTable7.Location = new System.Drawing.Point(682, 192);
            this.playAreaTable7.Name = "playAreaTable7";
            this.playAreaTable7.RowCount = 15;
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable7.Size = new System.Drawing.Size(80, 640);
            this.playAreaTable7.TabIndex = 6;
            // 
            // playAreaTable6
            // 
            this.playAreaTable6.AutoSize = true;
            this.playAreaTable6.ColumnCount = 1;
            this.playAreaTable6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.playAreaTable6.Location = new System.Drawing.Point(584, 192);
            this.playAreaTable6.Name = "playAreaTable6";
            this.playAreaTable6.RowCount = 15;
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable6.Size = new System.Drawing.Size(80, 640);
            this.playAreaTable6.TabIndex = 5;
            // 
            // playAreaTable5
            // 
            this.playAreaTable5.AutoSize = true;
            this.playAreaTable5.ColumnCount = 1;
            this.playAreaTable5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.playAreaTable5.Location = new System.Drawing.Point(486, 192);
            this.playAreaTable5.Name = "playAreaTable5";
            this.playAreaTable5.RowCount = 15;
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.666667F));
            this.playAreaTable5.Size = new System.Drawing.Size(80, 640);
            this.playAreaTable5.TabIndex = 4;
            // 
            // drawPilePicture
            // 
            this.drawPilePicture.BackColor = System.Drawing.Color.White;
            this.drawPilePicture.Location = new System.Drawing.Point(39, 44);
            this.drawPilePicture.Name = "drawPilePicture";
            this.drawPilePicture.Size = new System.Drawing.Size(65, 95);
            this.drawPilePicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.drawPilePicture.TabIndex = 7;
            this.drawPilePicture.TabStop = false;
            this.drawPilePicture.Click += new System.EventHandler(this.drawPilePicture_Click);
            // 
            // discardPilePicture
            // 
            this.discardPilePicture.Location = new System.Drawing.Point(133, 44);
            this.discardPilePicture.Name = "discardPilePicture";
            this.discardPilePicture.Size = new System.Drawing.Size(65, 95);
            this.discardPilePicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.discardPilePicture.TabIndex = 8;
            this.discardPilePicture.TabStop = false;
            this.discardPilePicture.Click += new System.EventHandler(this.discardPilePicture_Click);
            // 
            // suitPilePicture2
            // 
            this.suitPilePicture2.BackColor = System.Drawing.Color.White;
            this.suitPilePicture2.Location = new System.Drawing.Point(540, 44);
            this.suitPilePicture2.Name = "suitPilePicture2";
            this.suitPilePicture2.Size = new System.Drawing.Size(65, 95);
            this.suitPilePicture2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.suitPilePicture2.TabIndex = 10;
            this.suitPilePicture2.TabStop = false;
            this.suitPilePicture2.Click += new System.EventHandler(this.suitPilePicture2_Click);
            // 
            // suitPilePicture1
            // 
            this.suitPilePicture1.BackColor = System.Drawing.Color.White;
            this.suitPilePicture1.Location = new System.Drawing.Point(446, 44);
            this.suitPilePicture1.Name = "suitPilePicture1";
            this.suitPilePicture1.Size = new System.Drawing.Size(65, 95);
            this.suitPilePicture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.suitPilePicture1.TabIndex = 9;
            this.suitPilePicture1.TabStop = false;
            this.suitPilePicture1.Click += new System.EventHandler(this.suitPilePicture1_Click);
            // 
            // suitPilePicture4
            // 
            this.suitPilePicture4.BackColor = System.Drawing.Color.White;
            this.suitPilePicture4.Location = new System.Drawing.Point(728, 44);
            this.suitPilePicture4.Name = "suitPilePicture4";
            this.suitPilePicture4.Size = new System.Drawing.Size(65, 95);
            this.suitPilePicture4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.suitPilePicture4.TabIndex = 12;
            this.suitPilePicture4.TabStop = false;
            this.suitPilePicture4.Click += new System.EventHandler(this.suitPilePicture4_Click);
            // 
            // suitPilePicture3
            // 
            this.suitPilePicture3.BackColor = System.Drawing.Color.White;
            this.suitPilePicture3.Location = new System.Drawing.Point(634, 44);
            this.suitPilePicture3.Name = "suitPilePicture3";
            this.suitPilePicture3.Size = new System.Drawing.Size(65, 95);
            this.suitPilePicture3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.suitPilePicture3.TabIndex = 11;
            this.suitPilePicture3.TabStop = false;
            this.suitPilePicture3.Click += new System.EventHandler(this.suitPilePicture3_Click);
            // 
            // Solitaire_Game_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(884, 891);
            this.Controls.Add(this.suitPilePicture4);
            this.Controls.Add(this.suitPilePicture3);
            this.Controls.Add(this.suitPilePicture2);
            this.Controls.Add(this.suitPilePicture1);
            this.Controls.Add(this.discardPilePicture);
            this.Controls.Add(this.drawPilePicture);
            this.Controls.Add(this.playAreaTable7);
            this.Controls.Add(this.playAreaTable6);
            this.Controls.Add(this.playAreaTable5);
            this.Controls.Add(this.playAreaTable4);
            this.Controls.Add(this.playAreaTable3);
            this.Controls.Add(this.playAreaTable2);
            this.Controls.Add(this.playAreaTable1);
            this.Name = "Solitaire_Game_Form";
            this.Text = "Solitaire";
            ((System.ComponentModel.ISupportInitialize)(this.drawPilePicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.discardPilePicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.suitPilePicture2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.suitPilePicture1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.suitPilePicture4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.suitPilePicture3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel playAreaTable1;
        private System.Windows.Forms.TableLayoutPanel playAreaTable2;
        private System.Windows.Forms.TableLayoutPanel playAreaTable4;
        private System.Windows.Forms.TableLayoutPanel playAreaTable3;
        private System.Windows.Forms.TableLayoutPanel playAreaTable7;
        private System.Windows.Forms.TableLayoutPanel playAreaTable6;
        private System.Windows.Forms.TableLayoutPanel playAreaTable5;
        private System.Windows.Forms.PictureBox drawPilePicture;
        private System.Windows.Forms.PictureBox discardPilePicture;
        private System.Windows.Forms.PictureBox suitPilePicture2;
        private System.Windows.Forms.PictureBox suitPilePicture1;
        private System.Windows.Forms.PictureBox suitPilePicture4;
        private System.Windows.Forms.PictureBox suitPilePicture3;
    }
}